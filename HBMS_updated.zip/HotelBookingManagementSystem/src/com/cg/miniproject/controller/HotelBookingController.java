package com.cg.miniproject.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.hibernate.engine.transaction.jta.platform.internal.JOTMJtaPlatform;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.service.IHotelBookingService;

@Controller("/hbms")
public class HotelBookingController {
	@Autowired
	IHotelBookingService service;

	@RequestMapping("index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("home");
		return view;
	}

	@RequestMapping("login")
	public ModelAndView getLoginPage() {
		ModelAndView view = new ModelAndView("login", "user1", new User());
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
		return view;
	}

	@RequestMapping("register")
	public ModelAndView getRegisterPage() {
		ModelAndView view = new ModelAndView("register", "user", new User());
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
		return view;
	}

	
@RequestMapping(value="registerDetails",method=RequestMethod.POST)
public ModelAndView storeDetails(@ModelAttribute("user") @Valid User user,BindingResult result)
{
	ModelAndView view = new ModelAndView();
	if(result.hasErrors())
	{
		view=new ModelAndView("register","user",user);
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
	}
	else
	{
		try {
			boolean res=service.register(user);
			if(res)
			{
				System.out.println("success");
			}
			else
			{
				System.out.println("failure");
			}
		} catch (HotelException e) {
		}
		view.setViewName("home");
		
	}
	return view;
	
}

@RequestMapping(value="fetchLoginDetails")
public ModelAndView getDetails(@ModelAttribute("user1") @Valid User user,BindingResult result)
{
	ModelAndView view = new ModelAndView();
	
	System.out.println("Login Page");
	if(result.hasErrors())
	{
		view = new ModelAndView("login", "user1", user);
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
	}
	else
	{
		try {
			boolean result1=service.login(user);
			if(result1)
			{
				/*view.setViewName("home");*/
				if (user.getRole().equals("Admin")) {
					view=new ModelAndView("DisplayForAdmin","hotel",new Hotel());	
				} else {
					
					ArrayList<Hotel> hotels = service.getHotelList();
					
					if (!hotels.isEmpty()) {
						//System.out.println(hotels);
						view=new ModelAndView("DisplayForUser","room",new RoomDetails());
						view.addObject("hotelList", hotels);
						
					} else {
						String msg = "No hotels are available for Booking!";
						view.addObject("msg", msg);
					}
					
				}
			}
			else
			{
				view = new ModelAndView("login", "user1", user);
				ArrayList<String> roles = new ArrayList<String>();
				roles.add("User");
				roles.add("Employee");
				roles.add("Admin");
				view.addObject("roles", roles);
				view.addObject("message", "Login Failed");
			}
			
		} catch (HotelException e) {
			
		}
		
	}
	return view;
	
}

@RequestMapping("getRoomDetails")
public ModelAndView getRoomDetails(@ModelAttribute("room") RoomDetails details)
{
	ModelAndView view=new ModelAndView();
	try {
		ArrayList<RoomDetails> list=service.getRoomDetails(details.getHotelId());
		System.out.println(list);
		if(!list.isEmpty())
		{
			ArrayList<Hotel> hotels = service.getHotelList();
			view=new ModelAndView("DisplayForUser","room",new RoomDetails());
			view.addObject("hotelList", hotels);
			view.addObject("roomDetails", list);
			
			
		}
		
	} catch (HotelException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return view;
	
}
@RequestMapping("AddHotel")
public ModelAndView getAddHotelPage()
{
	ModelAndView view=new ModelAndView("AddHotel","hotel",new Hotel());
	return view;
	
}

@RequestMapping("addHotelDetails")
public ModelAndView saveHotelDetails(@ModelAttribute("hotel") @Valid Hotel hotel,BindingResult result) {
	
	ModelAndView view=new ModelAndView();
	if(result.hasErrors())
	{
		view=new ModelAndView("AddHotel","hotel",hotel);
	}
	else
	{
		try {
			boolean result2=service.addHotels(hotel);
			if(result2)
			{
				view=new ModelAndView("DisplayForAdmin","hotel",new Hotel());	
			}
			
		} catch (HotelException e) {

		}
	}
	return view;
	
}
@RequestMapping("DeleteHotel")
public ModelAndView getDeleteHotelPage()
{
	ModelAndView view=new ModelAndView("DeleteHotel","hotel",new Hotel());
	return view;
	
}
@RequestMapping("deleteHotelDetails")
public ModelAndView deleteHotelDetails(@ModelAttribute("hotel") Hotel hotel)
{
	ModelAndView view=new ModelAndView();
	try {
		boolean result=service.deleteHotel(hotel.getHotelId());
		if(result)
		{
			view=new ModelAndView("DisplayForAdmin","hotel",new Hotel());	
		}
	} catch (HotelException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return view;
	
}
@RequestMapping("ModifyHotel")
public ModelAndView getModifyHotelPage()
{
	ModelAndView view=new ModelAndView("ModifyHotel","hotel",new Hotel());
	return view;
	
}

@RequestMapping("modifyHotelDetails")
public ModelAndView modifyHotelDetails(@ModelAttribute("hotel") @Valid Hotel hotel,BindingResult result)
{
	System.out.println(hotel.getHotelId());
	ModelAndView view=new ModelAndView();
	if(result.hasErrors())
	{
		view=new ModelAndView("ModifyHotel","hotel",hotel);
	}
	else
	{
	try {
		boolean result2=service.modifyHotel(hotel);
		if(result2)
		{
			view=new ModelAndView("DisplayForAdmin","hotel",new Hotel());
		}
	} catch (HotelException e) {
		
	}
	}
	
	return view;
	
}
@RequestMapping("getHotelDetailsById")
public ModelAndView getHotelDetailsById(@ModelAttribute("hotel") Hotel hotel) {

	ModelAndView view=new ModelAndView();
		ArrayList<Hotel> list=service.getHotelList(hotel.getHotelId());
		//System.out.println(list);
		if(!list.isEmpty())
		{
			view=new ModelAndView("ModifyHotel","hotel",new Hotel());
			view.addObject("hotelDetails",list);
		}
	return view;
	
}
}