package com.cg.miniproject.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.util.DBConnection;
@Repository
@Transactional
public class HotelBookingDaoImpl implements IHotelBookingDao {
	boolean b, result = false;

	@PersistenceContext
	EntityManager entityManager;
	/*
	 * To register a new user/employee
	 */
	@Override
	public boolean register(User user) throws HotelException {

		entityManager.persist(user);
		entityManager.flush();
		b=true;
		return b;
	}
	/*
	 * To login a user/employee
	 */
	public boolean login(User user) throws HotelException {

		Query query=entityManager.createNamedQuery("login");
		query.setParameter("uname", user.getUserName());
		query.setParameter("pwd", user.getPassword());
		query.setParameter("role", user.getRole());
		List<User> list=query.getResultList();
		if(!list.isEmpty())
			b=true;
		return b;
	}

	/*
	 * To add Hotels in the hotel table
	 */
	@Override
	public boolean addHotels(Hotel hotel) throws HotelException {
		
		entityManager.persist(hotel);
		entityManager.flush();
		result=true;
			return result;
	}

	/*
	 * To delete hotel based on hotel Id
	 */
	@Override
	public boolean deleteHotel(Integer id) throws HotelException {
	
		Hotel hotel=entityManager.find(Hotel.class,id);
		entityManager.remove(hotel);
		result=true;
		return result;
	}
	/*
	 * To add new rooms for a particular hotel
	 */
	@Override
	public boolean addRooms(RoomDetails roomDetails) throws HotelException {
		try {
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY5);
			preparedStatement.setString(1, roomDetails.getHotelId());
			preparedStatement.setString(2, roomDetails.getRoomId());
			preparedStatement.setString(3, roomDetails.getRoomNo());
			preparedStatement.setString(4, roomDetails.getRoomType());
			preparedStatement.setDouble(5, roomDetails.getPerNightRate());
			preparedStatement.setString(6, roomDetails.getAvailability());
			int rows_updated = preparedStatement.executeUpdate();
			if (rows_updated > 0)
				result = true;
		} catch (SQLException e) {

			throw new HotelException(
					"Tehnical problem occured while adding rooms!!!");
		}

		return result;
	}
	/*
	 * To delete rooms for a particular hotel based on room id
	 */
	@Override
	public boolean deleteRooms(String id) throws HotelException {
		Connection connection = DBConnection.getConnection();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY6);
			preparedStatement.setString(1, id);
			int rows_updated = preparedStatement.executeUpdate();
			if (rows_updated > 0)
				result = true;
		} catch (SQLException e) {

			throw new HotelException(
					"Tehnical problem occured while deleting rooms!!!");
		}
		return result;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id 
	 */
	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId)
			throws HotelException {
		ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
		Connection connection = DBConnection.getConnection();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY7);
			preparedStatement.setString(1, hotelId);
			preparedStatement.executeQuery();
			ResultSet resultSet = preparedStatement.getResultSet();
			if (!resultSet.isBeforeFirst())
				System.err.println("No data found with given hotel id");
			while (resultSet.next()) {
				BookingDetails details = new BookingDetails();
				details.setBookingId(resultSet.getString(1));
				details.setRoomId(resultSet.getString(2));
				details.setUserId(resultSet.getString(3));
				/*details.setBookedFrom(resultSet.getString(4));
				details.setBookedTo(resultSet.getString(5));*/
				details.setNoOfAdults(resultSet.getInt(6));
				details.setNoOfChildren(resultSet.getInt(7));
				details.setAmount(resultSet.getDouble(8));
				list.add(details);
			}
		}

		catch (Exception e) {
			throw new HotelException("Tehnical problem occured !!!");
		}
		return list;
	}
	/*
	 * To retrieve bookings for a particular hotel based on Date 
	 */
	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException {

		ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
		Connection connection = DBConnection.getConnection();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY8);

			preparedStatement.setString(1, Date.valueOf(date).toString());
			preparedStatement.setString(2, Date.valueOf(date).toString());
			preparedStatement.executeQuery();
			ResultSet resultSet = preparedStatement.getResultSet();
			if (!resultSet.isBeforeFirst())
				System.err.println("No data found for specified date");

			while (resultSet.next()) {

				BookingDetails details = new BookingDetails();
				details.setBookingId(resultSet.getString(1));
				details.setRoomId(resultSet.getString(2));
				details.setUserId(resultSet.getString(3));
				/*details.setBookedFrom(resultSet.getString(4));
				details.setBookedTo(resultSet.getString(5));*/
				details.setNoOfAdults(resultSet.getInt(6));
				details.setNoOfChildren(resultSet.getInt(7));
				details.setAmount(resultSet.getDouble(8));
				list.add(details);
			}
		}

		catch (Exception e) {

			throw new HotelException("Tehnical problem occured !!!");
		}
		return list;

	}
	/*
	 * To retrieve list of hotels 
	 */
	@Override
	public ArrayList<Hotel> getHotelList() throws HotelException {
	
		Query query=entityManager.createNamedQuery("listAllHotels");
		ArrayList<Hotel> list=(ArrayList<Hotel>) query.getResultList();
		return list;
	}
	/*
	 * To retrieve room details based on hotel Id
	 */
	@Override
	public ArrayList<RoomDetails> getRoomDetails(String id)
			throws HotelException {

		Query query=entityManager.createNamedQuery("getRoomDetails");
		ArrayList<RoomDetails> list=(ArrayList<RoomDetails>) query.getResultList();
		return list;
	}
	/*
	 * To insert booking details into database
	 */
	@Override
	public boolean insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		boolean result = false;
		/*DateTimeFormatter dateFormat = DateTimeFormatter
				.ofPattern("dd/MM/yyyy");
		LocalDate startDate = LocalDate.parse(bookingDetails.getBookedFrom(),
				dateFormat);
		LocalDate endDate = LocalDate.parse(bookingDetails.getBookedTo(),
				dateFormat);
		Period period = Period.between(startDate, endDate);
		Integer diff = period.getDays();
		User user = new User();
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			PreparedStatement statement = connection
					.prepareStatement(IQueryMapper.QUERY11);
			statement.setString(1, bookingDetails.getRoomId());
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				RoomDetails details = new RoomDetails();
				details.setPerNightRate(resultSet.getDouble(1));
				Double amount = details.getPerNightRate() * diff;
				preparedStatement = connection
						.prepareStatement(IQueryMapper.QUERY12);
				preparedStatement.setString(1, bookingDetails.getRoomId());
				preparedStatement.setString(2, bookingDetails.getUserId());
				preparedStatement.setDate(3, Date.valueOf(startDate));
				preparedStatement.setDate(4, Date.valueOf(endDate));
				preparedStatement.setLong(5, bookingDetails.getNoOfAdults());
				preparedStatement.setLong(6, bookingDetails.getNoOfChildren());
				preparedStatement.setDouble(7, amount);
				int rowsUpdated = preparedStatement.executeUpdate();
				if (rowsUpdated > 0) {
					PreparedStatement preparedStatement2 = connection
							.prepareStatement(IQueryMapper.QUERY13);
					preparedStatement2.setString(1, bookingDetails.getRoomId());
					preparedStatement2.executeUpdate();
					result = true;
				}
			}
		} catch (SQLException e) {

			throw new HotelException("Insertion Failed!!!");
		}*/
		return result;
	}
	/*
	 * To retrieve user Id 
	 */
	@Override
	public User fetchUserId(User user) throws HotelException {
		User userdetails = new User();
		Connection connection = DBConnection.getConnection();
		try {

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY14);
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getRole());
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				/*userdetails.setUserId(resultSet.getString(1));*/

			}
		} catch (SQLException e) {

			throw new HotelException("Failed in Fetching the details!!!");
		}
		return userdetails;
	}
	/*
	 * To retrieve bookings for a particular hotel based on hotel Id 
	 */
	@Override
	public ArrayList<BookingDetails> retrieveGuestList(String hotelId)
			throws HotelException {
		ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
		Connection connection = DBConnection.getConnection();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY15);
			preparedStatement.setString(1, hotelId);
			preparedStatement.executeQuery();
			ResultSet resultSet = preparedStatement.getResultSet();
			if (!resultSet.isBeforeFirst())
				System.err.println("No data found with given hotel id");
			while (resultSet.next()) {
				BookingDetails details = new BookingDetails();
				details.setNoOfAdults(Integer.parseInt(resultSet.getString(1)));
				details.setNoOfChildren(Integer.parseInt(resultSet.getString(2)));
				list.add(details);
			}
		} catch (Exception e) {
			throw new HotelException("No data Found");
		}
		return list;
	}
	/*
	 * To validate user name
	 */
	@Override
	public boolean validateName(User user) throws HotelException {
		boolean res = false;
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY16);
			preparedStatement.setString(1, user.getUserName());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				res = true;
			}

		} catch (SQLException e) {
			throw new HotelException("Same name exists");
		}
		return res;
	}
	/*
	 * To retrieve booking status based on booking details
	 */
	public boolean bookingStatus(BookingDetails details) throws HotelException {
		boolean res = false;
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY17);
			preparedStatement.setString(1, details.getUserId());
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				res = true;
			}
		} catch (SQLException e) {
			throw new HotelException("Booking status not available");
		}
		return res;
	}
	/*
	 * To modify hotel details
	 */
	@Override
	public boolean modifyHotel(Hotel hotel) throws HotelException {
		System.out.println(hotel.getHotelId());
		entityManager.merge(hotel);
		entityManager.flush();
		result=true;
		return result;
	}
	/*
	 * To modify room details 
	 */
	@Override
	public boolean modifyRoom(RoomDetails details) throws HotelException {
		try {
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY19);
			preparedStatement.setDouble(1, details.getPerNightRate());
			preparedStatement.setString(2, details.getHotelId());
			preparedStatement.setString(3, details.getRoomId());
			int rows_updated = preparedStatement.executeUpdate();
			if (rows_updated > 0)
				result = true;
		} catch (SQLException e) {

			throw new HotelException(
					"Tehnical problem occured while modifying !!!");
		}

		return result;
	}
	/*
	 * To validate hotel Id
	 */
	public boolean validateHotelId(Hotel hotel) throws HotelException {
		boolean res = false;
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY20);
			/*preparedStatement.setString(1, hotel.getHotelId());*/
			ResultSet resultSet = preparedStatement.executeQuery();
			if (!resultSet.isBeforeFirst()) {
				res = false;
			} else if (resultSet.next()) {
				res = true;
			}

		} catch (SQLException e) {
			throw new HotelException("Invalid Hotel Id");
		}
		return res;
	}
	@Override
	public ArrayList<Hotel> getHotelList(int hotelId) {
		Query query=entityManager.createNamedQuery("retrieveHotels");
		query.setParameter("id",hotelId);
		ArrayList<Hotel> list=(ArrayList<Hotel>) query.getResultList();
		return list;
	}
}
